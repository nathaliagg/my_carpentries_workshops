Notes on survey_data_2013.xlsx

19/04/2013

1. Received survey data from field season 2013 from John.


22/04/2013

2. In 2013-raw: raw data as received.

3. In 2013-clean:

  3.1 'Weight' in grams.
  3.2 Separated 'Species-Sex' column into two columns 'Species' and 'Sex'.
  3.3 Separated 'Date Collected' column into three columns 'Year', 'Month', and 'Day'.

4. In species_id.txt: taxonomy and respective codes of rodents.